import type { InstalledSkillList } from '../host/types.js';
type Item = InstalledSkillList['items'][number];
export declare function installedCardVersions(items: Item[]): {
    label: string;
    title: string;
};
export declare function InstalledCardMetadata({ items }: {
    items: Item[];
}): import("react/jsx-runtime").JSX.Element | null;
export {};
