import type { SkillHubConfig } from '../host/types.js';
export type SavedRegistry = NonNullable<SkillHubConfig['savedRegistries']>[number];
/** Match RegistryAdapter's canonical URL without inventing additional source aliases. */
export declare function registryAddress(value: string): string;
export declare function sameRegistry(left: string | undefined, right: string | undefined): boolean;
export declare function savedRegistryOptions(config: {
    registryUrl: string;
    savedRegistries?: readonly SavedRegistry[];
}): SavedRegistry[];
/** Indexes always refer to savedRegistries; the legacy current address has no saved index. */
export declare function registryChoices(config: Pick<SkillHubConfig, 'registryUrl' | 'savedRegistries'>): (SavedRegistry & {
    savedIndex: number | null;
})[];
/** Preserve a legacy address only when the user edits/selects, never on initial read. */
export declare function preserveCurrentRegistry(config: SkillHubConfig): SkillHubConfig;
export declare class RegistryConfigError extends Error {
    readonly savedIndex?: number | undefined;
    constructor(message: string, savedIndex?: number | undefined);
}
export declare function editSavedRegistry(config: SkillHubConfig, index: number, next?: SavedRegistry): SkillHubConfig;
export declare function validateRegistryConfig(config: SkillHubConfig): SkillHubConfig;
