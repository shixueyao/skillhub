import { type QueryClient, type UseMutationOptions } from '@tanstack/react-query';
import type { TypertRemoteNamespaceMap } from '@deepseek-ai/dsh-typert-protocol';
import type { FavoriteList, FavoriteSkill } from '../host/types.js';
import '../../lib/typert.remote-client.js';
type Remote = Pick<TypertRemoteNamespaceMap['skillhub'], 'listFavorites' | 'setFavorite'>;
interface FavoriteMutation {
    sourceRevision: string;
    item: FavoriteSkill;
    favorite: boolean;
    signal: AbortSignal;
}
/** Share serialization across observers of the same source, including a detail/card pair. */
export declare function favoriteMutationOptions(remote: Pick<Remote, 'setFavorite'>, client: QueryClient, sourceRevision: string | undefined): UseMutationOptions<FavoriteList, Error, FavoriteMutation>;
export declare function useFavorites(remote: Remote, sourceRevision: string | undefined, enabled: boolean): {
    items: FavoriteSkill[];
    loading: boolean;
    fetching: boolean;
    ready: boolean;
    saving: boolean;
    error: string | undefined;
    retry: () => void;
    save: (item: FavoriteSkill, favorite: boolean) => Promise<boolean>;
};
export {};
