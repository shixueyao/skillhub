import Schema from '@deepseek-ai/schemastery';
import type { SkillHubConfig } from './types.js';
export declare const Config: Schema<{
    registryUrl?: string | null;
    savedRegistries?: SkillHubConfig['savedRegistries'] | null;
    detailTabs?: Partial<SkillHubConfig['detailTabs']> | null;
}, SkillHubConfig, 'volatile-defined'>;
