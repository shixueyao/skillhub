import type { FavoriteSkill } from '../host/types.js';
export declare function FavoriteButton({ item, pressed, disabled, busy, onToggle }: {
    item: FavoriteSkill;
    pressed: boolean;
    disabled: boolean;
    busy: boolean;
    onToggle(): void;
}): import("react/jsx-runtime").JSX.Element;
