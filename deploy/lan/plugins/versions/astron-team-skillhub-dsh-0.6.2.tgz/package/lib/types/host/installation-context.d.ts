import { RemoteError } from '@deepseek-ai/dsh-typert-protocol';
/** Internal diagnostics only: never serialize an error message, context or identifier. */
export declare const installationContextReasons: readonly ["AGENT", "CWD", "SOURCE", "FS", "POLICY", "RUNTIME", "DETAIL", "TARGET", "HOST_MISMATCH"];
export type InstallationContextReason = typeof installationContextReasons[number];
type ContextMessage = 'Installation context changed.' | 'Conversation unavailable.' | 'Detail expired.' | 'Project unavailable.' | 'Installation context unavailable.' | 'Conversation changed.' | 'SkillHub source context changed.' | 'Reopen the skill detail and choose the installation target again.';
export declare function installationContextError(reason: InstallationContextReason, message?: ContextMessage): RemoteError;
export declare function installationContextReason(error: unknown): InstallationContextReason | undefined;
export {};
