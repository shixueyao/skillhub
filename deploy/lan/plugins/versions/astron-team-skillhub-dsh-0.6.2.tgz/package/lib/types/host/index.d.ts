import type { PackageImportPreview, PackageExport } from './types.js';
import type { InstallationContextReason } from './installation-context.js';
import { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { Config } from './config.js';
import type { SelectionSnapshot } from './conversation-selections.js';
import type { ManagementAction, ManagementRequest } from './management-tool.js';
import type { ConversationManagementResult } from './types.js';
import type { ConversationSearchContext, ConversationSearchResult } from './search-tool.js';
import type { RegistryConnectionTest, CatalogContext, CatalogLabels, CatalogPageResult, CatalogSort, ReviewPage, ConversationDetail, SkillDetail, SkillList, VersionPage } from './types.js';
import type { FavoriteList, FavoriteSkill, FavoriteVersion } from './types.js';
import type { HostCompatibility } from './types.js';
import type { UpgradePlanView, UninstallPlanView, TogglePlanView, HostExecutePlanRequest, HostRecoveryRequest } from './types.js';
import type { ResolvedInstallationTarget } from './installation-targets.js';
import type { SkillAvailability } from './types.js';
import type { PendingConversationInstall, CancelledConversationInstall } from './conversation-install-request.js';
import type { NativeOperation, HostInstallRequest } from './types.js';
import type { NativeRecoveryResult } from './generated/native-contract.js';
import type { InstallationTargetList } from './types.js';
import type { LocalRuntimeStatus } from './local-runtime.js';
import type { InstalledSkillList, InstalledSkillDetail, InstalledUpdateCheck, SkillUsePreparation, SkillUseSelection } from './types.js';
import type { ChangesView, ChangeDiffView, FileResetPlanView } from './types.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        skillhub: SkillHubService;
    }
}
/** Native SkillHub service with session-scoped installation and read-only catalog methods. */
export declare class SkillHubService extends TypertRemoteService {
    static Config: typeof Config;
    private readonly configuration;
    private sourceRevision;
    private registry?;
    private sourceInput;
    private readonly lifetime;
    private localRuntime?;
    private readonly favorites;
    private readonly selections;
    private readonly pendingConversationInstalls;
    private readonly pendingConversationChoices;
    private readonly managementRequests;
    private readonly managementConfirmations;
    private readonly installationTargets;
    private readonly upgradePlans;
    private readonly changeBackups;
    private readonly packageImports;
    private packagePreviewBytes;
    private readonly changes;
    private readonly resets;
    private readonly removalPlans;
    private readonly togglePlans;
    private readonly installedUpdateScans;
    private readonly installedReferenceKey;
    private readonly capabilities;
    private readonly details;
    constructor(ctx: Context, configuration?: ReturnType<typeof Config>);
    private installationContextDiagnostic?;
    /** Internal smoke diagnostics; no paths, messages or identifiers, and no Remote exposure. */
    getInstallationContextDiagnostic(): InstallationContextReason | undefined;
    /** Internal diagnostics, deliberately not a Remote method. */
    getLocalRuntimeStatus(): LocalRuntimeStatus | null;
    private refreshSource;
    getStatus(): string;
    /** Probe an unsaved address independently of the active source and its selection state. */
    testRegistryConnection(inputUrl: string, signal: AbortSignal): Promise<RegistryConnectionTest>;
    private assertRuntimeBaseline;
    getCompatibility(): HostCompatibility;
    getContext(): CatalogContext;
    listFavorites(sourceRevision: string, signal: AbortSignal): Promise<FavoriteList>;
    setFavorite(sourceRevision: string, item: FavoriteSkill, favorite: boolean, signal: AbortSignal): Promise<FavoriteList>;
    resolveFavoriteVersion(sourceRevision: string, namespace: string, slug: string, signal: AbortSignal): Promise<FavoriteVersion>;
    private readFavoriteCoordinates;
    private readFavorites;
    listSkills(sourceRevision: string, query: string, signal: AbortSignal): Promise<SkillList>;
    listCatalog(sourceRevision: string, query: string, page: number, sort: CatalogSort, signal: AbortSignal): Promise<CatalogPageResult>;
    listLabels(sourceRevision: string, signal: AbortSignal): Promise<CatalogLabels>;
    listCatalogByLabel(sourceRevision: string, query: string, page: number, sort: CatalogSort, label: string, signal: AbortSignal): Promise<CatalogPageResult>;
    getSkillDetail(sourceRevision: string, namespace: string, slug: string, version: string, signal: AbortSignal): Promise<SkillDetail>;
    listVersions(detailToken: string, page: number, signal: AbortSignal): Promise<VersionPage>;
    listReviews(detailToken: string, page: number, signal: AbortSignal): Promise<ReviewPage>;
    listInstalled(sourceRevision: string, signal: AbortSignal): Promise<InstalledSkillList>;
    /** Tools use explicit trusted context, never a forged Remote invocation. */
    private listInstalledForAgent;
    checkAvailability(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<SkillAvailability>;
    private checkAvailabilityForAgent;
    /** Resolve coordinates through the current DSH winner; no scope/version preference or write. */
    selectSkillUse(sourceRevision: string, namespace: string, slug: string, signal: AbortSignal): Promise<SkillUseSelection>;
    /** Read-only handoff: installed snapshots and market names never authorize an invocation. */
    prepareSkillUse(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<SkillUsePreparation>;
    previewPackageImport(sourceRevision: string, base64: string, signal: AbortSignal): Promise<PackageImportPreview>;
    confirmPackageImport(sourceRevision: string, previewId: string, scope: 'user' | 'project', requestKey: string, signal: AbortSignal): Promise<NativeOperation | null>;
    exportInstalledPackage(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<PackageExport>;
    private packageContext;
    getInstalledDetail(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<InstalledSkillDetail>;
    beginInstalledUpdateScan(sourceRevision: string, signal: AbortSignal): Promise<{
        scanId: string;
        itemKeys: string[];
    }>;
    checkInstalledUpdateScan(sourceRevision: string, scanId: string, itemKey: string, signal: AbortSignal): Promise<InstalledUpdateCheck>;
    endInstalledUpdateScan(sourceRevision: string, scanId: string): Promise<void>;
    checkUpdate(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<InstalledUpdateCheck>;
    checkVersionUpdate(sourceRevision: string, itemKey: string, version: string, signal: AbortSignal): Promise<InstalledUpdateCheck>;
    private checkUpdateForVersion;
    inspectLocalChanges(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<ChangesView>;
    readFileChange(sourceRevision: string, itemKey: string, snapshotId: string, path: string, signal: AbortSignal): Promise<ChangeDiffView>;
    previewUpgradeChanges(sourceRevision: string, itemKey: string, snapshotId: string, version: string | null, backup: boolean, signal: AbortSignal): Promise<ChangesView>;
    confirmUpgradeChanges(sourceRevision: string, itemKey: string, snapshotId: string, signal: AbortSignal): Promise<UpgradePlanView>;
    prepareFileReset(sourceRevision: string, itemKey: string, snapshotId: string, paths: string[], signal: AbortSignal): Promise<FileResetPlanView>;
    executeFileReset(sourceRevision: string, itemKey: string, request: HostExecutePlanRequest & {
        hostInstanceId: string;
    }, signal: AbortSignal): Promise<NativeOperation | null>;
    prepareUpgrade(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<UpgradePlanView>;
    prepareVersionUpgrade(sourceRevision: string, itemKey: string, version: string, signal: AbortSignal): Promise<UpgradePlanView>;
    private prepareUpgradeForVersion;
    prepareToggle(sourceRevision: string, itemKey: string, desiredState: 'enabled' | 'disabled', signal: AbortSignal): Promise<TogglePlanView>;
    private prepareToggleForAgent;
    prepareUninstall(sourceRevision: string, itemKey: string, signal: AbortSignal): Promise<UninstallPlanView>;
    private prepareUninstallForAgent;
    /** Opaque references are stable within a Host and bind the full trusted record snapshot. */
    private installedItemKey;
    private readInstalledItem;
    executePlan(input: HostExecutePlanRequest, signal: AbortSignal): Promise<NativeOperation | null>;
    private executePlanForAgent;
    openConversationDetail(selectionRef: string, signal: AbortSignal): Promise<ConversationDetail>;
    /** Reissue only from this session's trusted search log; never restore old authorization. */
    reopenConversationDetail(callId: string, selectionRef: string, signal: AbortSignal): Promise<ConversationDetail>;
    acknowledgeConversationDetail(selectionRef: string, detailToken: string): boolean;
    listInstallTargets(detailToken: string, signal: AbortSignal): Promise<InstallationTargetList>;
    private installationTargetsFor;
    startInstall(input: HostInstallRequest, signal: AbortSignal): Promise<NativeOperation | null>;
    getOperation(operationId: string, hostInstanceId: string): Promise<NativeOperation | null>;
    recoverOperation(input: HostRecoveryRequest): Promise<NativeOperation | null>;
    private selectionScope;
    /** Trusted coordinator shared by the scoped Remote and the forthcoming installation tool. */
    submitInstallation(agentId: string, input: HostInstallRequest, signal: AbortSignal): Promise<NativeOperation | undefined>;
    private prepareInstallation;
    /** Use the Host question surface without creating an operation until a human answers. */
    installConversationWithChoice(input: unknown, context: ConversationSearchContext, signal: AbortSignal): Promise<NativeOperation | PendingConversationInstall | CancelledConversationInstall | undefined>;
    /** Stable tool identity is checked in the journal before resolving ephemeral detail/target references. */
    installConversation(input: unknown, context: ConversationSearchContext, signal: AbortSignal): Promise<NativeOperation | PendingConversationInstall | undefined>;
    /** Internal owner-scoped query shared with the pending UI adapter. */
    getInstallationOperation(agentId: string, operationId: string): Promise<NativeOperation | undefined>;
    /** Internal recovery for an existing session; historical sources are never queried or reinstalled. */
    recoverInstallationOperation(agentId: string, operationId: string): Promise<NativeRecoveryResult | undefined>;
    /** Internal only: page and tool execution share this final target-reference check. */
    resolveInstallationTarget(agentId: string, detailToken: string, targetToken: string, signal: AbortSignal): Promise<{
        target: ResolvedInstallationTarget;
        snapshot: SelectionSnapshot;
    }>;
    private conversationSelection;
    resolveConversationSelection(agent: {
        session: {
            id: string;
            header: {
                cwd?: string;
            };
        };
    }, reference: string): {
        selectionRef: string;
        detailToken: string;
        snapshot: SelectionSnapshot;
    };
    searchConversation(query: string, context: ConversationSearchContext, signal: AbortSignal): Promise<ConversationSearchResult>;
    /** Model adapters always supply trusted exec context; never synthesize a Remote invocation. */
    manageConversation(action: ManagementAction, input: ManagementRequest, context: ConversationSearchContext, signal: AbortSignal, useQuestions?: boolean): Promise<object>;
    beginConversationManagement(sourceRevision: string, itemKey: string, action: 'upgrade' | 'uninstall' | 'enable' | 'disable', version: string | null, requestKey: string, signal: AbortSignal): Promise<ConversationManagementResult>;
    /** Only a trusted Client event or native userQuestions answer can enter this confirmation path. */
    confirmConversationManagement(confirmationRef: string, confirmed: boolean, signal: AbortSignal): Promise<ConversationManagementResult>;
    private confirmManagementForAgent;
    private readDetail;
    private assertSource;
    private readSource;
}
export default SkillHubService;
