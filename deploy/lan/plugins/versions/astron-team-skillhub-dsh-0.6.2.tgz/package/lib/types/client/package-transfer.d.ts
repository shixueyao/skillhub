import { type SkillUseServices } from './use-skill.js';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { InstalledSkillList, NativeOperation } from '../host/types.js';
export declare const MAX_TRANSFER_BYTES: number;
export interface PackagePreview {
    previewId: string;
    name: string;
    summary?: string;
    files: number;
    bytes: number;
    expiresAt: string;
}
export interface PackageTransferServices {
    preview(revision: string, base64: string, signal: AbortSignal): Promise<RemoteResult<PackagePreview>>;
    confirm(revision: string, preview: string, scope: 'user' | 'project', requestKey: string, signal: AbortSignal): Promise<RemoteResult<NativeOperation | null>>;
}
export declare function encodePackage(bytes: Uint8Array): string;
export declare function packageDownload(base64: string, filename: string): void;
export declare function PackagePreviewContent({ preview }: {
    preview: PackagePreview;
}): import("react/jsx-runtime").JSX.Element;
export declare function importProgressView(operation: Pick<NativeOperation, 'phase' | 'warningCount' | 'recovery' | 'resultDetails'> | undefined, confirming: boolean, readFailed: boolean): {
    label: string;
    state: "stopped";
} | {
    label: string;
    state: "ready" | "running";
} | {
    label: string;
    state: "complete";
};
export declare function PackageImport({ transfer, revision, contextKey, services, onCompleted }: {
    transfer: PackageTransferServices;
    revision: string;
    contextKey: string;
    services: {
        sessionId: string;
        skillUse?: SkillUseServices;
        list?(revision: string, signal: AbortSignal): Promise<RemoteResult<InstalledSkillList>>;
        operation(id: string, host: string): Promise<RemoteResult<NativeOperation | null>>;
    };
    onCompleted(): void;
}): import("react/jsx-runtime").JSX.Element;
