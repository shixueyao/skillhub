import type { FavoriteSkill, FavoriteVersion, SkillList } from '../host/types.js';
export declare const favoritesKey: (sourceRevision: string | undefined) => readonly ["skillhub-favorites", string | undefined];
export declare const favoriteIdentity: (item: Pick<FavoriteSkill, "namespace" | "slug">) => string;
/** Persist public display text only, never a version, installation token or metrics. */
export declare function favoriteSnapshot(item: FavoriteSkill): FavoriteSkill;
export declare function filterFavorites(items: FavoriteSkill[], query: string): FavoriteSkill[];
/** A saved snapshot becomes a catalog selection only after a current-source resolve. */
export declare function resolvedFavoriteItem(item: FavoriteSkill, version: FavoriteVersion): SkillList['items'][number];
