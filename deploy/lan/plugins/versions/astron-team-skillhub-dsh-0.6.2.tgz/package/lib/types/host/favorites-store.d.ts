import type { FavoriteList, FavoriteSkill } from './types.js';
export declare const favoriteLimits: {
    readonly items: 500;
    readonly bytes: number;
};
type Reason = 'INVALID_INPUT' | 'UNAVAILABLE' | 'INVALID_STORE' | 'LIMIT_REACHED';
export declare class FavoritesError extends Error {
    readonly reason: Reason;
    constructor(reason: Reason);
}
export declare function validateFavoriteSkill(input: unknown): FavoriteSkill;
/** User preferences only: no inventory, skill directory, or Registry mutation. */
export declare class FavoritesStore {
    private readonly home?;
    constructor(home?: string | undefined);
    list(registry: string, assertCurrent?: () => void): Promise<FavoriteList>;
    set(registry: string, input: FavoriteSkill, favorite: boolean, assertCurrent?: () => void): Promise<FavoriteList>;
    private location;
    private read;
}
export {};
