import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ChangesView, ChangeDiffView, FileResetPlanView, HostExecutePlanRequest, NativeOperation, UpgradePlanView } from '../host/types.js';
import type { UpgradeServices } from './upgrade-control.js';
export interface ChangeServices {
    inspect(revision: string, itemKey: string, signal: AbortSignal): Promise<RemoteResult<ChangesView>>;
    diff(revision: string, itemKey: string, snapshotId: string, path: string, signal: AbortSignal): Promise<RemoteResult<ChangeDiffView>>;
    preview(revision: string, itemKey: string, snapshotId: string, version: string | null, backup: boolean, signal: AbortSignal): Promise<RemoteResult<ChangesView>>;
    confirm(revision: string, itemKey: string, snapshotId: string, signal: AbortSignal): Promise<RemoteResult<UpgradePlanView>>;
    prepareReset(revision: string, itemKey: string, snapshotId: string, paths: string[], signal: AbortSignal): Promise<RemoteResult<FileResetPlanView>>;
    reset(revision: string, itemKey: string, input: HostExecutePlanRequest & {
        hostInstanceId: string;
    }, signal: AbortSignal): Promise<RemoteResult<NativeOperation | null>>;
}
export declare function ChangePreviewStyles(): import("react/jsx-runtime").JSX.Element;
/** Sequential local handling → release differences → final explicit acceptance. */
export declare function ChangePreview({ services, revision, itemKey, upgrade, targetVersion, installationKey, onClose, onCompleted }: {
    services: UpgradeServices & {
        changes: ChangeServices;
    };
    revision: string;
    itemKey: string;
    upgrade: boolean;
    targetVersion?: string;
    installationKey?: string;
    onClose(): void;
    onCompleted?(version: string): void;
}): import("react/jsx-runtime").JSX.Element;
