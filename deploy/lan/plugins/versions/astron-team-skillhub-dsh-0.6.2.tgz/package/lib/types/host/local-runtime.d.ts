import { type OperationDiagnostic } from './operation-diagnostic.js';
import type { UpdateIdentity, UpdateAssessment, InstalledProjection, InstalledProjectionTarget } from './generated/native-contract.js';
import type { UpgradeSelection, UpgradeBaseline } from './generated/native-contract.js';
import type { NativeUpgradeExecution } from './generated/native-contract.js';
import type { RemovalBaseline, NativeRemovalExecution } from './generated/native-contract.js';
import type { ToggleBaseline, NativeToggleExecution, InstallationState } from './generated/native-contract.js';
import type { NativeRuntime, NativeInstallExecution, NativeInstallAcceptance, NativeOperationRequest, NativeOperation, NativeRecoveryResult, NativePendingOperation } from './generated/native-contract.js';
export interface LocalRuntimeStatus {
    state: 'starting' | 'ready' | 'failed' | 'closing' | 'disposed';
    hostInstanceId: string | null;
    pendingOperations: number;
}
export interface PreparedNativeInstall {
    acceptance: NativeInstallAcceptance;
    execution: Omit<NativeInstallExecution, 'operationId' | 'ownerId'>;
}
export interface PreparedNativeUpgrade {
    acceptance: NativeInstallAcceptance;
    execution: Omit<NativeUpgradeExecution, 'operationId' | 'ownerId'>;
}
export interface PreparedNativeRemoval {
    acceptance: NativeInstallAcceptance & {
        kind: 'uninstall' | 'remove-stale-record';
    };
    execution: Omit<NativeRemovalExecution, 'operationId' | 'ownerId'>;
}
export interface PreparedNativeToggle {
    acceptance: NativeInstallAcceptance & {
        kind: 'enable' | 'disable';
    };
    execution: Omit<NativeToggleExecution, 'operationId' | 'ownerId'>;
}
/** Host-only initialization; no Client path input and no automatic replay of historical writes. */
export declare class LocalRuntime {
    private readonly open;
    private readonly assertWritableHost;
    private readonly reportFailure;
    private disposed;
    private runtime?;
    private starting?;
    private closing?;
    private readonly pending;
    private readonly startupPending;
    private status;
    constructor(open?: () => Promise<NativeRuntime>, assertWritableHost?: () => void, reportFailure?: (diagnostic: OperationDiagnostic) => void);
    start(): Promise<void>;
    private initialize;
    getStatus(): LocalRuntimeStatus;
    acceptInstall(request: NativeOperationRequest, validateNew: () => Promise<NativeInstallAcceptance>): Promise<NativeOperation | undefined>;
    getOperation(operationId: string, ownerId: string): Promise<NativeOperation | undefined>;
    observeInstallation(operationId: string, ownerId: string, roots: readonly string[], observe: (paths: readonly string[]) => Promise<boolean>): Promise<boolean>;
    findPlanOperation(request: NativeOperationRequest): Promise<NativeOperation | undefined>;
    assessUpdate(installed: UpdateIdentity, candidate: UpdateIdentity): Promise<UpdateAssessment>;
    inspectUpgrade(selected: UpgradeSelection, targets: readonly InstalledProjectionTarget[]): Promise<UpgradeBaseline>;
    inspectChanges(...args: Parameters<NativeRuntime['inspectChanges']>): Promise<import("./generated/native-contract.js").LocalChangesSnapshot>;
    readChangeDiff(...args: Parameters<NativeRuntime['readChangeDiff']>): Promise<import("./generated/native-contract.js").BoundedFileDiff>;
    prepareVersionChanges(...args: Parameters<NativeRuntime['prepareVersionChanges']>): Promise<import("./generated/native-contract.js").VersionChangesSnapshot>;
    backupChanges(...args: Parameters<NativeRuntime['backupChanges']>): Promise<import("./generated/native-contract.js").VerifiedBackupReceipt>;
    submitFileReset(request: NativeOperationRequest, prepare: () => Promise<{
        acceptance: NativeInstallAcceptance;
        execution: Omit<Parameters<NativeRuntime['executeFileReset']>[0], 'operationId' | 'ownerId'>;
    }>): Promise<NativeOperation | undefined>;
    inspectRemoval(selected: UpgradeSelection, target: InstalledProjectionTarget): Promise<RemovalBaseline>;
    inspectToggle(selected: UpgradeSelection, target: InstalledProjectionTarget, desiredState: InstallationState): Promise<ToggleBaseline>;
    readInstallationEntry(selected: UpgradeSelection, target: InstalledProjectionTarget): Promise<string | undefined>;
    readSkillExamples(directory: string): ReturnType<NativeRuntime['readSkillExamples']>;
    openInstalledSnapshot(registry: string, targets: readonly InstalledProjectionTarget[]): Promise<{
        projection: InstalledProjection;
        read(item: import("./generated/native-contract.js").InstalledProjectionItem): Promise<import("./generated/native-contract.js").InstalledProjectionItem>;
    }>;
    listAllInstalled(targets: readonly InstalledProjectionTarget[]): ReturnType<NativeRuntime['listAllInstalled']>;
    listInstalled(registry: string, targets: readonly InstalledProjectionTarget[]): Promise<InstalledProjection>;
    executeInstall(request: NativeInstallExecution): Promise<NativeRecoveryResult>;
    /** Host resolves historical targets from trusted context; neither Client nor model supplies paths. */
    recoverOperation(operationId: string, ownerId: string, prepare: (operation: NativePendingOperation) => Promise<Parameters<NativeRuntime['recover']>[3]>): Promise<NativeRecoveryResult | undefined>;
    /** Acceptance is returned early; the complete admitted workflow remains tracked until execution settles. */
    submitInstall(request: NativeOperationRequest, prepare: () => Promise<PreparedNativeInstall>): Promise<NativeOperation | undefined>;
    previewPackage(...args: Parameters<NativeRuntime['previewPackage']>): Promise<{
        name: string;
        summary?: string;
        files: number;
        bytes: number;
        fingerprint: string;
    }>;
    exportPackage(...args: Parameters<NativeRuntime['exportPackage']>): Promise<{
        filename: string;
        archive: Uint8Array;
    }>;
    submitPackageImport(request: NativeOperationRequest, prepare: () => Promise<PreparedNativeInstall & {
        archive: Uint8Array;
    }>): Promise<NativeOperation | undefined>;
    private call;
    submitUpgrade(request: NativeOperationRequest, prepare: () => Promise<PreparedNativeUpgrade>): Promise<NativeOperation | undefined>;
    submitRemoval(request: NativeOperationRequest, prepare: () => Promise<PreparedNativeRemoval>): Promise<NativeOperation | undefined>;
    submitToggle(request: NativeOperationRequest, prepare: () => Promise<PreparedNativeToggle>): Promise<NativeOperation | undefined>;
    private executeAccepted;
    private track;
    dispose(): Promise<void>;
}
